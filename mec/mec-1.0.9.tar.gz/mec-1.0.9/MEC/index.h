//-----------------------------------------------
// Copyright 2016 Guangxi University
// Written by Liang Zhao(S080011@e.ntu.edu.sg)
// Released under the GPL
//-----------------------------------------------
//
// index - Build a BWT/FM-index for a set of reads
// It's developed based on SGA, originally writen by Jared Simpson (js18@sanger.ac.uk)
//

#ifndef INDEX_H
#define INDEX_H
#include <getopt.h>
#include <string>
#include "config.h"
#include "SuffixArray.h"

int indexMain(int argc, char **argv);
void indexInMemoryRopebwt();
void parseIndexOptions(int argc, char** argv);

#endif
