//-----------------------------------------------
// Copyright 2016 Guangxi University
// Written by Liang Zhao(S080011@e.ntu.edu.sg)
// Released under the GPL
//-----------------------------------------------
//
// preprocess - prepare data files for error correction 
// It's developed based on SGA, originally writen by Jared Simpson (js18@sanger.ac.uk)
//

#ifndef PREPROCESS_H
#define PREPROCESS_H
#include <getopt.h>
#include "config.h"
#include "Quality.h"
#include "Util.h"


// functions
int preprocessMain(int argc, char** argv);
void parsePreprocessOptions(int argc, char** argv);
bool processRead(SeqRecord& record);
int countLowQuality(const std::string& seq, const std::string& qual);

#endif
