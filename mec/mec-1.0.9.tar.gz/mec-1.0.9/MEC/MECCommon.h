//-----------------------------------------------
// Copyright 2016 Guangxi University
// Written by Liang Zhao(S080011@e.ntu.edu.sg)
// Released under the GPL
//-----------------------------------------------
//
// MECCommon.h - Common definitions used in the programs 
// It's developed based on SGA, originally writen by Jared Simpson (js18@sanger.ac.uk)
//


#ifndef MECCOMMON_H
#define MECCOMMON_H

// File extensions
#define OVR_EXT ".ovr"
#define HITS_EXT ".hits"
#define RMDUPHITS_EXT ".rmhits"
#define GMAPHITS_EXT ".gmhits"
#define CTN_EXT ".ctn"
#define ASQG_EXT ".asqg"
#define SA_EXT ".sa"
#define RSA_EXT ".rsa"
#define BWT_EXT ".bwt"
#define RBWT_EXT ".rbwt"
#define SAI_EXT ".sai"
#define RSAI_EXT ".rsai"
#define SSA_EXT ".ssa"
#define POPIDX_EXT ".popidx"

// Default values
#define DEFAULT_MIN_OVERLAP 25
#define DEFAULT_EXTRACT_LEN 100

#endif
